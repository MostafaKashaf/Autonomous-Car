
"use strict";

let test_custom_msg = require('./test_custom_msg.js');

module.exports = {
  test_custom_msg: test_custom_msg,
};
